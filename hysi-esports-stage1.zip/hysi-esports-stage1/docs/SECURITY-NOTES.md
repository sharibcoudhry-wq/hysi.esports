# Security notes

- Never commit secrets or place service-role/OpenAI keys in `NEXT_PUBLIC_*`.
- Keep RLS enabled on every exposed table.
- Add policies only after defining each table's read/write rules.
- Validate all request bodies with Zod on the server.
- Use database transactions for registration and rewards.
- Enforce block checks in the database/service layer for every messaging entry point.
- Validate uploads by MIME sniffing, size, ownership and allowed extensions; store privately.
- Escape user-generated text at render boundaries; avoid unsafe HTML rendering.
- Rate-limit auth, chat, search, reports and AI endpoints.
- Keep audit records for privileged actions.
- Configure Supabase backups and periodically test restore procedures.
