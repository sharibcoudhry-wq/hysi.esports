# HYSI ESPORTS — Architecture

## High-level flow
Browser → Next.js App Router → server actions / route handlers → Supabase Auth + PostgreSQL + Storage + Realtime. HYSI AI calls OpenAI only from server-side routes.

## Planned folder structure
```text
src/
  app/
    (public)/
    (auth)/
    player/
    tournaments/
    social/
    ai/
    streams/
    admin/
    api/
    globals.css
    layout.tsx
  components/
    layout/
    ui/
    tournaments/
    player/
    social/
  lib/
    auth/
    permissions/
    supabase/
    validation/
    security/
  server/
    services/
    repositories/
    actions/
supabase/
  migrations/
  seed/
docs/
```

## Core boundaries
- UI components never decide whether a user is an admin.
- Route handlers and server actions validate input and authorize every operation.
- Supabase RLS is the final data-access boundary; application checks are additional, not a replacement.
- Privileged service-role access is restricted to server-only modules and used only where necessary.
- Room secrets are separated from public tournament rows and encrypted at rest by application-level encryption.
- Statistics and leaderboards are derived only from approved `verified_results`.
- Coin balances are derived from immutable ledger entries, never accepted from client-supplied totals.

## Role model
`owner`, `moderator`, `player`. A normal signup receives `player`. Owner provisioning is a controlled server/database operation. Moderators receive explicit permissions and cannot grant themselves roles.

## Database notes
`0001_foundation.sql` establishes core entities, foreign keys, uniqueness constraints, useful indexes and RLS enablement. Later migrations must add the minimum policies required for each feature. Until a policy exists, RLS denies access.

## Atomic tournament registration
Registration must be implemented as a PostgreSQL function / transaction that:
1. Locks the tournament row.
2. Confirms registration window and status.
3. Checks duplicate registration.
4. Counts confirmed entries.
5. Assigns a slot or waitlist status.
6. Inserts the registration.
This must never be split into independent browser requests.

## Stage plan
1. Architecture, schema, design system — included here.
2. Responsive navigation and page shells.
3. Supabase Auth, email verification, password reset, permanent Player ID.
4. Player profile and dashboard.
5. Tournament lifecycle and atomic registration.
6. Private rooms and tournament chat.
7. Friends, follows, DMs, blocks.
8. HYSI AI with server-side key and permission-safe tools.
9. YouTube Live Center.
10. Coins, XP, seasons, badges, verified leaderboards.
11. Clans, squads and recruitment.
12. Owner/moderator admin tools.
13. Reports, support, moderation and notifications.
14. SEO, testing, deployment and operational hardening.
