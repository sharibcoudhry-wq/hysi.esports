import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HYSI ESPORTS — Play Together. Rise Together.",
  description: "Free Fire esports tournaments and player community.",
  applicationName: "HYSI ESPORTS",
  openGraph: {
    title: "HYSI ESPORTS",
    description: "Play Together. Rise Together.",
    type: "website"
  }
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
