import Link from "next/link";
export default function PlayerEntry() {
  return <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6">
    <Link href="/" className="mb-8 text-sm text-violet-300">← Back to HYSI ESPORTS</Link>
    <div className="surface rounded-3xl p-8">
      <div className="text-xs font-bold tracking-[.25em] text-violet-300">PLAYER PORTAL</div>
      <h1 className="display-font mt-3 text-5xl font-bold">PLAYER ACCESS</h1>
      <p className="mt-3 text-sm leading-6 text-slate-400">Player registration, sign-in, verification and dashboard are scheduled for Stage 3. No account is created on this placeholder page.</p>
      <div className="mt-6 rounded-xl border border-amber-300/20 bg-amber-300/5 p-4 text-sm text-amber-100">Setup status: Supabase credentials and authentication flow are not configured yet.</div>
    </div>
  </main>;
}
