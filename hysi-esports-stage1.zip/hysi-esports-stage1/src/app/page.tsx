import Link from "next/link";
import { ShieldCheck, Trophy, Users, Zap, Gamepad2, ArrowUpRight } from "lucide-react";

const features = [
  { icon: Trophy, title: "Competitive tournaments", text: "Solo, duo and squad events with transparent registration and verified results." },
  { icon: Users, title: "Player community", text: "Build your player profile, connect with teammates and grow your clan." },
  { icon: ShieldCheck, title: "Fair-play first", text: "Private room access, moderation and admin-reviewed match submissions." },
  { icon: Zap, title: "HYSI AI", text: "Get help understanding rules, registrations and platform features." }
];

export default function HomePage() {
  return (
    <main className="mx-auto min-h-screen max-w-7xl px-5 py-6 sm:px-8">
      <header className="flex items-center justify-between border-b border-white/10 pb-5">
        <Link href="/" className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-violet-500 to-sky-400 font-black text-black">H</div>
          <div>
            <div className="display-font text-2xl font-extrabold tracking-wider">HYSI <span className="gradient-text">ESPORTS</span></div>
            <div className="text-[10px] tracking-[.28em] text-slate-500">PLAY TOGETHER. RISE TOGETHER.</div>
          </div>
        </Link>
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="h-2 w-2 rounded-full bg-violet-400 shadow-glow" /> PLATFORM FOUNDATION
        </div>
      </header>

      <section className="grid items-center gap-12 py-20 lg:grid-cols-[1.15fr_.85fr] lg:py-28">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-400/25 bg-violet-400/10 px-4 py-2 text-xs font-semibold tracking-wide text-violet-200">
            <Gamepad2 size={15} /> FREE FIRE ESPORTS COMMUNITY
          </div>
          <h1 className="display-font max-w-3xl text-6xl font-extrabold uppercase leading-[.92] sm:text-8xl">
            Your game.<br /><span className="gradient-text">Your legacy.</span>
          </h1>
          <p className="mt-7 max-w-xl text-base leading-7 text-slate-400">
            Compete in organized tournaments, build your player identity and rise with a community built around fair play.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/player" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-violet-500 to-blue-500 px-6 py-3.5 text-sm font-bold shadow-glow transition hover:brightness-110">
              Enter as Player <ArrowUpRight size={17} />
            </Link>
            <Link href="/admin" className="rounded-xl border border-white/15 bg-white/[.04] px-6 py-3.5 text-sm font-semibold text-slate-200 transition hover:bg-white/[.08]">
              Admin access
            </Link>
          </div>
          <p className="mt-4 text-xs text-slate-600">Authentication and protected dashboards are implemented in upcoming development stages.</p>
        </div>

        <div className="surface relative overflow-hidden rounded-3xl p-6 sm:p-8">
          <div className="absolute -right-16 -top-20 h-64 w-64 rounded-full bg-violet-600/20 blur-3xl" />
          <div className="relative">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold tracking-[.2em] text-slate-400">HYSI ARENA</span>
              <span className="rounded-full border border-sky-300/20 bg-sky-300/10 px-3 py-1 text-[10px] font-bold text-sky-200">FOUNDATION</span>
            </div>
            <div className="my-12 text-center">
              <div className="display-font text-7xl font-extrabold tracking-widest text-white/90">HYSI</div>
              <div className="mt-2 text-xs tracking-[.4em] text-slate-500">ESPORTS NETWORK</div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="text-xs text-slate-500">Game focus</div><div className="mt-1 font-bold">Free Fire</div></div>
              <div className="rounded-2xl border border-white/10 bg-black/20 p-4"><div className="text-xs text-slate-500">Platform goal</div><div className="mt-1 font-bold">Competitive + Social</div></div>
            </div>
          </div>
        </div>
      </section>

      <section className="pb-20">
        <div className="mb-7">
          <div className="text-xs font-bold tracking-[.25em] text-violet-300">BUILT FOR THE COMMUNITY</div>
          <h2 className="display-font mt-2 text-4xl font-bold sm:text-5xl">Everything starts with fair play.</h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map(({ icon: Icon, title, text }) => (
            <article key={title} className="surface rounded-2xl p-5">
              <div className="mb-5 grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br from-violet-500/20 to-sky-400/10 text-violet-200"><Icon size={21} /></div>
              <h3 className="font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-400">{text}</p>
            </article>
          ))}
        </div>
      </section>

      <footer className="flex flex-col gap-2 border-t border-white/10 py-6 text-xs text-slate-600 sm:flex-row sm:justify-between">
        <span>© {new Date().getFullYear()} HYSI ESPORTS</span>
        <span>PLAY TOGETHER. RISE TOGETHER.</span>
      </footer>
    </main>
  );
}
