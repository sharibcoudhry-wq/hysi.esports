import Link from "next/link";
export default function AdminEntry() {
  return <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6">
    <Link href="/" className="mb-8 text-sm text-violet-300">← Back to HYSI ESPORTS</Link>
    <div className="surface rounded-3xl p-8">
      <div className="text-xs font-bold tracking-[.25em] text-sky-300">RESTRICTED AREA</div>
      <h1 className="display-font mt-3 text-5xl font-bold">ADMIN ACCESS</h1>
      <p className="mt-3 text-sm leading-6 text-slate-400">The protected admin login and server-side role checks will be implemented in later stages. This route currently grants no access or permissions.</p>
      <div className="mt-6 rounded-xl border border-amber-300/20 bg-amber-300/5 p-4 text-sm text-amber-100">Security note: never grant owner privileges through public signup.</div>
    </div>
  </main>;
}
