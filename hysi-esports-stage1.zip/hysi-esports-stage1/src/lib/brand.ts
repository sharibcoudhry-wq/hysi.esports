export const BRAND = {
  name: "HYSI ESPORTS",
  tagline: "PLAY TOGETHER. RISE TOGETHER.",
  game: "Free Fire"
} as const;
